<!-- Readme.md v1.1.1
Jack-O-Lantern (JOL)
created: 23 Sep 19
updated: 31 Oct 19 -->

<!-- Download on SpaceDock or Github or Curseforge. Also available on CKAN. -->

# Jack-O-Lantern (JOL)
Jack-O'-Lantern by Porkjet. Jack-O'Lantern themed probe cores in three sizes. All the modcons.

![Mod Version](https://img.shields.io/github/v/release/zer0Kerbal/Jack-O-Lantern?include_prereleases) 
![KSP 1.7.x](https://img.shields.io/badge/KSP%20version-1.7.x-66ccff.svg?style=flat-square) 
![CKAN listed](https://img.shields.io/badge/CKAN-Indexed-brightgreen.svg) ![CC 4.0 BY-NC-SA](https://img.shields.io/badge/license-CC--4.0--BY--SA-lightgrey)

Internally supports TweakScale

![Jack-O-Lantern](https://i.imgur.com/6Dvavcc.jpg)
![Jack-O-Lantern](https://i.imgur.com/gWlegrN.jpg)

<!-- 
CC BY-NC-SA-4.0
zer0Kerbal 
-->
